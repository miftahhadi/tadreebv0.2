

<?php $__env->startSection('page'); ?>
<!-- Classroom header -->
<div class="card">
    <div class="card-body">
        <?php echo e($kelas->group->nama); ?>

        <h2><?php echo e($kelas->nama); ?></h2>
    </div>
    <div class="card-footer">
        <ul class="nav nav-pills justify-content-center">
        <?php $__currentLoopData = $kelas->pages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="nav-item">
                <a href="<?php echo e($page['link']); ?>" class="nav-link <?php if(strpos(url()->current(), strtolower($page['title']))): ?> active <?php endif; ?>"><?php echo e($page['title']); ?></a>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
</div>
<!-- Classroom header -->

<?php echo $__env->yieldContent('classContent'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/tadreeb/resources/views/front/classroom/main.blade.php ENDPATH**/ ?>