

<?php $__env->startSection('page'); ?>

<!-- Page Title and Stuffs -->

    <nav aria-label="breadcrumb" class="row">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="#"><?php echo e($grup->nama); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page">Kelas Baru</li>
        </ol>
    </nav>
    <h3 class="row page-title">Tambah Kelas Baru</h3>        


<!-- END Page Title and Stuffs -->
<form action="/admin/grup/<?php echo e($grup->id); ?>/kelas" method="post">
<?php echo csrf_field(); ?>
    <div class="row">
        <div class="card">
            <div class="card-body">
                <div class="form-group">
                    <label class="form-label">Nama kelas<span class="form-required">*</span></label>
                    <input type="text" class="form-control <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="nama" placeholder="Tuliskan nama" value="<?php echo e(old('nama') ?? ''); ?>">

                    <?php $__errorArgs = ['nama'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>

                <div class="form-group">
                    <label class="form-label">
                        Deskripsi
                        <span class="form-label-small">Maks: 600 karakter</span>
                    </label>
                    <textarea class="form-control <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="deskripsi" rows="6" placeholder="Deskripsi..."><?php echo e(old('deskripsi') ?? ''); ?></textarea>
                
                    <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
            </div>
        </div>

        <a href="#" class="btn btn-secondary mr-1">Batal</a>
        <input type="submit" name="submit" value="Simpan" class="btn btn-primary">
    </div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/tadreeb/resources/views/admin/classroom/create.blade.php ENDPATH**/ ?>