

<?php $__env->startSection('page'); ?>
<!-- Page Title and Stuffs -->
<div class="row">
  <div class="page-header">
    <h3 class="page-title">Mata Pelajaran Baru</h3>
  </div>
</div>
<!-- END Page Title and Stuffs -->
<form action="/admin/pelajaran" method="post">
<?php echo csrf_field(); ?>
  <div class="row">
    <div class="card">
      <div class="card-body">
        <div class="form-group">
          <label class="form-label">Judul<span class="form-required">*</span></label>
          <input type="text" class="form-control <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="judul" placeholder="Tuliskan judul" value="<?php echo e(old('judul') ?? ''); ?>">

          <?php $__errorArgs = ['judul'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        <div class="form-group">
          <label class="form-label">Slug<span class="form-required">*</span></label>
          <div class="input-group">
            <span class="input-group-prepend" id="basic-addon3">
              <span class="input-group-text"><?php echo e($_SERVER['SERVER_NAME']); ?>/pelajaran/</span>
            </span>
            <input type="text" name="slug" class="form-control <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" placeholder="judul-pelajaran-anda" value="<?php echo e(old('slug') ?? ''); ?>">
          </div>
          <small>Gunakan (-) sebagai pemisah antar kata, bukan spasi</small><br>

          <?php $__errorArgs = ['slug'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <small class="text-danger"><?php echo e($message); ?></small>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>  

        </div>

        <div class="form-group">
          <label class="form-label">Deskripsi</label>
          <textarea class="form-control <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="deskripsi" rows="6" placeholder="Deskripsi..." value="<?php echo e(old('deskripsi') ?? ''); ?>"></textarea>
        
          <?php $__errorArgs = ['deskripsi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid-feedback"><?php echo e($message); ?></div>
          <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        </div>

        

      </div>
    </div>
    <a href="#" class="btn btn-secondary mr-1">Batal</a>
    <input type="submit" name="submit" value="Simpan" class="btn btn-primary">
  </div>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/tadreeb/resources/views/admin/lesson/create.blade.php ENDPATH**/ ?>