

<?php $__env->startSection('page'); ?>
<!-- Page Title and Stuffs -->
<div class="page-header">
    <div>
        <div class="page-description"><?php echo e($kelas->group->nama); ?></div>
        <h3 class="page-title">Tambah Pelajaran ke <?php echo e($kelas->nama); ?></h3>
    </div>
</div>
<!-- END Page Title and Stuffs -->

<div class="card">
    <table class="table card-table table-vcenter"  id="app">
        <tr>
            <th class="w-1">
            </th>
            <th>Nama</th>
            <th class="d-none d-sm-table-cell">Kategori</th>
            <th class="d-none d-md-table-cell"></th>
        </tr>
        <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th>
                <label class="custom-control custom-checkbox">
                    <input type="checkbox" class="custom-control-input" name="users[]" value="<?php echo e($user->id); ?>">
                    <div class="custom-control-label"></div>
                </label>
            </th>
            <td><?php echo e($lesson->judul); ?></td>
            <td class="d-none d-sm-table-cell"></td>
            <td class="d-none d-md-table-cell text-right"><assign-user-button user-id="<?php echo e($user->id); ?>" kelas-id="<?php echo e($kelas->id); ?>" assigned="<?php echo e($assigned[$user->id]); ?>"></assign-user-button></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>
<input type="submit" value="Tambahkan ke kelas" class="btn btn-primary">
<script type="text/javascript" src="/js/app.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/tadreeb/resources/views/admin/classroom/tambah-pelajaran.blade.php ENDPATH**/ ?>