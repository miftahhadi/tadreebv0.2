

<?php $__env->startSection('page'); ?>
<div class="col-lg-8">
    <h1><?php echo e($message); ?></h1>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/tadreeb/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>