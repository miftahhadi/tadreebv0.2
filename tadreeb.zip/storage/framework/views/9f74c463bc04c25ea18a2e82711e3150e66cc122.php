

<?php $__env->startSection('page'); ?>
<ol class="breadcrumb" aria-label="breadcrumbs">
    <li class="breadcrumb-item"><a href="#">Dashboard</a></li>
    <li class="breadcrumb-item"><a href="#">Daftar Ujian</a></li>
    <li class="breadcrumb-item"><a href="#"><?php echo e($exam->judul); ?></a></li>
    <li class="breadcrumb-item active" aria-current="page"><a href="#">Buat Soal Baru</a></li>
</ol>

<form action="/admin/ujian/<?php echo e($exam->id); ?>/soal" method="post">
<?php echo csrf_field(); ?>

<div class="row mt-3 mb-4">
    <div class="col-auto">
        <h2 class="h1">Soal Baru</h2>
    </div>
    
    <div class="col-auto ml-auto">
        <input type="submit" value="Simpan" class="btn btn-success">
        <a href="<?php echo e(route('exam.show', ['exam' => $exam->id])); ?>" class="btn btn-white">Batal</a>
    </div>
</div>

<div class="card">
    <div class="card-header">
        Redaksi Soal
    </div>
    <div class="card-body">

        <?php $__errorArgs = ['soal[konten]'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class="text-danger">Soal belum diisi</small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <textarea class="form-control" name="soal[konten]" id="redaksi" placeholder="Tuliskan soal..."></textarea>
    </div>
</div>

<?php if(request('type') == 'multiple' || request('type') == 'single'): ?>
<input type="hidden" name="soal[tipe]" value="<?php echo e(request('type') == 'single' ? 1 : 2); ?>">

<h4 class="card-title">Pilihan Jawaban</h4>

<?php for($i = 0; $i < $choices; $i++): ?>

<div class="card">
    <div class="card-header">
      Pilihan <?php echo e($i + 1); ?>

    </div>
    <div class="card-body" id="cardSoal">
        <textarea name="jawaban[<?php echo e($i); ?>][redaksi]"></textarea>
    </div> 
    
    <div class="card-footer">
        <div class="row">
            <div class="col-md-2">
                <div class="form-group">
                    <div class="form-label">Pilihan Benar</div>
                    <label class="form-check">
                        <input type="<?php echo e($option); ?>" class="form-check-input" name="jawaban[<?php echo e($i); ?>][benar]" value="1">
                        <span class="form-check-label">Benar</span>
                    </label>
                </div>
            </div>

            <div class="col-md-3">
                <div class="form-group">
                    <label class="form-label">Nilai</label>
                    <input type="number" class="form-control" name="jawaban[<?php echo e($i); ?>][nilai]" placeholder="Nilai" value="0">
                </div>
            </div>  

        </div>
    </div>

</div>
<?php endfor; ?>

<?php elseif(request('type') == 'benarsalah' || request('type') == 'benarsalahArabic'): ?>
<input type="hidden" name="soal[tipe]" value="3">
<h4 class="card-title">Pilihan Jawaban</h4>
<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <label class="form-check">
                    <input type="radio" class="form-check-input" name="jawaban[1][benar]" value="1">
                    <input type="hidden" name="jawaban[1][redaksi]" value="<?php echo e($value['benar']); ?>">
                    <div class="form-check-label"><?php echo e($value['benar']); ?></div>
                </label>
            </div>

            <div class="card-footer">

                <div class="form-group">
                    <label class="form-label">Nilai</label>
                    <input type="number" class="form-control" placeholder="Nilai" value="0" name="jawaban[1][nilai]">
                </div>
 
            </div>

        </div>
    </div>

    <div class="col-md-6">
        <div class="card">
            <div class="card-body">
                <label class="form-check">
                    <input type="radio" class="form-check-input" name="jawaban[2][benar]" value="1">
                    <input type="hidden" name="jawaban[2][redaksi]" value="<?php echo e($value['salah']); ?>">
                    <div class="form-check-label"><?php echo e($value['salah']); ?></div>
                </label>
            </div>

            <div class="card-footer">
                
                <div class="form-group">
                    <label class="form-label">Nilai</label>
                    <input type="number" class="form-control" placeholder="Nilai" value="0" name="jawaban[2][nilai]">
                </div>

            </div>

        </div>
    </div>
</div>

<?php elseif(request('type') == 'text'): ?>
<input type="hidden" name="soal[tipe]" value="4">
<?php endif; ?>

</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/tadreeb/resources/views/admin/question/create.blade.php ENDPATH**/ ?>