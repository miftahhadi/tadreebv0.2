

<?php $__env->startSection('classContent'); ?>
<div class="page-header">
    <div class="page-title">
        Tambah Anggota
    </div>
</div>
<form action="#" method="post">
    <div class="card">
        <table class="table card-table table-vcenter"  id="app">
            <tr>
                <th class="w-1">
                </th>
                <th>Nama</th>
                <th class="d-none d-sm-table-cell">Username</th>
                <th class="d-none d-md-table-cell"></th>
            </tr>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th>
                    <input class="form-check-input m-0 align-middle" type="checkbox" aria-label="Pilih peserta ini" id="peserta[<?php echo e($user->id); ?>]">
                </th>
                <td><label for="peserta[<?php echo e($user->id); ?>]"><?php echo e($user->nama); ?></label></td>
                <td class="d-none d-sm-table-cell"><?php echo e($user->username); ?></td>
                <td class="d-none d-md-table-cell text-right"><assign-user-button user-id="<?php echo e($user->id); ?>" kelas-id="<?php echo e($kelas->id); ?>" assigned="<?php echo e($assigned[$user->id]); ?>"></assign-user-button></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    <div class="btn-list">
        <a href="<?php echo e(route('kelas.anggota', ['kelas' => $kelas->id])); ?>" class="btn btn-white">Kembali</a>
        <input type="submit" value="Tambahkan ke kelas" class="btn btn-primary">
    </div>
</form>


<script type="text/javascript" src="/js/app.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.classroom.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vagrant/Code/tadreeb/resources/views/front/classroom/tambah-anggota.blade.php ENDPATH**/ ?>