@extends('layouts.admin')

@section('page')
<div class="col-lg-8">
    <h1>{{ $message }}</h1>
</div>
@endsection